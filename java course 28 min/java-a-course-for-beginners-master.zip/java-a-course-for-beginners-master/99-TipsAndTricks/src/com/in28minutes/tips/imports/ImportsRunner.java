package com.in28minutes.tips.imports;

//import java.lang.*; //DEFAULT
import java.math.BigDecimal;
import java.util.ArrayList;
//import java.util.Collections;

import static java.lang.System.out;
import static java.util.Collections.*;

public class ImportsRunner {

	public static void main(String[] args) {
		
		out.println("IMports");
		out.println("Static Imports");
		
		sort(new ArrayList<String>());
		
		BigDecimal db = null;

	}

}
