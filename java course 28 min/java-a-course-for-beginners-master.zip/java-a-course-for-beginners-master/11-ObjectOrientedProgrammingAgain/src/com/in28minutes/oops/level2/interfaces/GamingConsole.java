package com.in28minutes.oops.level2.interfaces;

public interface GamingConsole {
	public void up();
	public void down();
	public void left();
	public void right();
}
