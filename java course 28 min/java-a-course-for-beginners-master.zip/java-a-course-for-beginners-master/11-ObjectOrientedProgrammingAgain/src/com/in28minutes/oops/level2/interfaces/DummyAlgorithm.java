package com.in28minutes.oops.level2.interfaces;

public class DummyAlgorithm implements ComplexAlgorithm{

	@Override
	public int complexAlgorithm(int number1, int number2) {
		return number1 + number2;
	}

}
